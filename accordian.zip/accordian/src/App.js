import React from 'react';
import logo from './logo.svg';
import './App.css';
import Wrapper from "./components/counter";
import Button from "./components/accordian"

function App() {
  return (
    <div className="App">
      {/* <Wrapper /> */}
      <Button />
    </div>
  );
}

export default App;
