import React, { Component, useState } from 'react';

// class Acc extends Component {
//     state = {
//         isActive : true
//       }

//       handleClick = () => {
//         this.setState({isActive: !this.state.isActive});
//       }

//     render() { 
//         return ( 
//             <div>
//                 <button onClick = {this.handleClick}>{this.props.message}
//                     {this.state.isActive ? "+" : "-" }
//                 </button>
//                 {!this.state.isActive && <div className = "acc_value">{this.props.messageAfter}</div>}    

//             </div>
//          );
//     }
// }

function Accordian(props){
    const [active, setactive] = useState(true);

    const handleClick = {setactive()}
    return (
        <div>
                <button onClick = {handleClick}>{props.message}
                    {this.state.isActive ? "+" : "-" }
                </button>
                {handleClick && <div className = "acc_value">{props.messageAfter}</div>}    

            </div>
    )
}


function Button(props){
    return (
        <div>
            <Accordian message = {"First One"} messageAfter = {"After First"}/>
            <Accordian message = {"Second One"} messageAfter = {"After Second"} />
            <Accordian message = {"Third One"} messageAfter = {"After Third"}/>
            <Accordian message = {"Fourth One"} messageAfter = {"After Fourth"}/>
        </div>
    )
}

export default Button;

