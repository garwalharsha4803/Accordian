import React, { Component , useState} from 'react';


function Counter(props){
    
    return <div>
        <button onClick = {() => props.onclickFunction(props.increment)} className = "btn btn-primary"> + {props.increment}</button>
    </div>
}

function Display(props){
    return (
        <div>
            {props.message}
        </div>
    )
}

function Wrapper(){
     const [counter, setCounter] = useState(1);
     const incrementFunction = (incrementvalue) => setCounter(counter+incrementvalue)
    return (
        <div>
            <Counter onclickFunction = {incrementFunction} increment = {1} /> 
            <Counter onclickFunction = {incrementFunction} increment = {10} /> 
            <Counter onclickFunction = {incrementFunction} increment = {100} /> 
            <Display message = {counter} /> 
           
        </div>
    )
}

export default Wrapper